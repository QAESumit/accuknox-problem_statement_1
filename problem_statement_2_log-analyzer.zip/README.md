
# Log File Analyzer

## Description
This script analyzes web server logs (e.g., Apache, Nginx) for common patterns such as the number of 404 errors, the most requested pages, and IP addresses with the most requests. The script outputs a summarized report.

## Usage

### Prerequisites
- Python 3.x

### Steps to Run

1. **Clone the Repository:**
   ```sh
   git clone <repository-url>
   cd log-analyzer
   ```

2. **Run the Script:**
   ```sh
   python log_analyzer.py path/to/your/logfile.log
   ```

### Example
```sh
python log_analyzer.py /var/log/apache2/access.log
```

## Expected Output
- Total Requests: Number of total requests in the log file.
- Status Counts: Counts of each HTTP status code.
- Most Requested Pages: Top 5 most requested pages.
- Top IP Addresses: Top 5 IP addresses with the most requests.
