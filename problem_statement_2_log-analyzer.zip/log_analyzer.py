
import re
from collections import Counter

def analyze_log(file_path):
    with open(file_path, 'r') as file:
        logs = file.readlines()

    # Regular expressions to match log patterns
    pattern = re.compile(r'^(?P<ip>\S+) \S+ \S+ \[(?P<date>.*?)\] "(?P<method>\S+) (?P<url>\S+) \S+" (?P<status>\d+) \S+')
    status_counter = Counter()
    page_counter = Counter()
    ip_counter = Counter()

    for log in logs:
        match = pattern.match(log)
        if match:
            status = match.group('status')
            url = match.group('url')
            ip = match.group('ip')

            status_counter[status] += 1
            page_counter[url] += 1
            ip_counter[ip] += 1

    report = {
        'total_requests': len(logs),
        'status_counts': status_counter,
        'most_requested_pages': page_counter.most_common(5),
        'top_ip_addresses': ip_counter.most_common(5),
    }

    return report

def print_report(report):
    print("Total Requests:", report['total_requests'])
    print("Status Counts:")
    for status, count in report['status_counts'].items():
        print(f"  {status}: {count}")

    print("Most Requested Pages:")
    for page, count in report['most_requested_pages']:
        print(f"  {page}: {count}")

    print("Top IP Addresses:")
    for ip, count in report['top_ip_addresses']:
        print(f"  {ip}: {count}")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Analyze web server logs.")
    parser.add_argument('logfile', help="Path to the web server log file.")
    args = parser.parse_args()

    report = analyze_log(args.logfile)
    print_report(report)
