
import requests

def check_health(url):
    try:
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            return 'up'
        else:
            return 'down'
    except requests.RequestException:
        return 'down'

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Check the health of an application.")
    parser.add_argument('url', help="URL of the application to check.")
    args = parser.parse_args()

    status = check_health(args.url)
    print(f"The application is {status}.")
