
# Application Health Checker

## Description
This script checks the uptime of an application and determines if it is functioning correctly by checking HTTP status codes. It detects if the application is 'up' (functioning correctly) or 'down' (unavailable or not responding).

## Usage

### Prerequisites
- Python 3.x
- requests library

### Steps to Run

1. **Clone the Repository:**
   ```sh
   git clone <repository-url>
   cd health-checker
   ```

2. **Install the requests library:**
   ```sh
   pip install requests
   ```

3. **Run the Script:**
   ```sh
   python health_checker.py <url>
   ```

### Example
```sh
python health_checker.py http://example.com
```

## Expected Output
- The script will print whether the application is 'up' or 'down' based on the HTTP status code.
